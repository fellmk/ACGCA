#ifndef PUTONALLOMETRY_H
#define PUTONALLOMETRY_H
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//#include "head_files/misc_growth_funcs.h"


extern void putonallometry(tstates *st, sparms *p, gparms *gp, puton *pton, int i, double deltaw);


#endif
