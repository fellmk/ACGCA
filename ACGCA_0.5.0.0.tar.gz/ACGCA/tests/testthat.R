library(testthat)
library(ACGCA)

test_check("ACGCA")
