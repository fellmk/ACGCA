## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE---------------------------------------------------------
# A code block to show the values for acru taken from Ogle and Pacala (2009)

load("../data/acru.rda")
load("../data/parms.rda")

# disable scientific notation
options(scipen = 999) # default is 1

acru.data <- cbind(parms, acru)
library(knitr)
library(kableExtra)
knitr::kable(data.frame(parameter.names=parms, parameter.values=acru), "html") %>%
  kableExtra::kable_styling(full_width=FALSE, position = "left")

# return to default setting
options(scipen = 0)

## ------------------------------------------------------------------------
# Call the ACGCA model (growthloopR)
acgcaout <- ACGCA::growthloopR(sparms=acru, r0=0.0054, parmax=2060*0.5, years=50, fulloutput=TRUE)

# Plot the radius and height output from the model.
par(mar=c(4,4,1,1))
plot(x=0:800/16, y=acgcaout$r, type="l", xlab="time (years)", ylab="radius (m)")
plot(x=0:800/16, y=acgcaout$h, type="l", xlab="time (years)", ylab="height (m)")

