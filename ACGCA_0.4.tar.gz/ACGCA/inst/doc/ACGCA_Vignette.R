## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE---------------------------------------------------------
# A code block to show the values for acru taken from Ogle and Pacala (2009)

load("../data/acru.rda")
load("../data/parms.rda")

# disable scientific notation
options(scipen = 999) # default is 1

acru.data <- cbind(parms, acru)
library(knitr)
library(kableExtra)
knitr::kable(data.frame(parameter.names=parms, parameter.values=acru), "html") %>%
  kableExtra::kable_styling(full_width=FALSE, position = "left")

# return to default setting
options(scipen = 0)

## ------------------------------------------------------------------------
# Call the ACGCA model (runacgca)
acgcaout <- ACGCA::runacgca(sparms = acru, r0 = 0.0054, parmax = 2060*0.5, years = 50, fulloutput = FALSE)

# Plot the radius and height output from the model.
par(mar=c(4,4,1,1))
plot(x=0:800/16, y = acgcaout$r, type="l", xlab = "time (years)", ylab = "radius (m)")
plot(x=0:800/16, y = acgcaout$h, type="l", xlab = "time (years)", ylab = "height (m)")

## ------------------------------------------------------------------------
# Set up a light vector for a 50 year simulation where light decreases 10% per decade
decrease <- seq(from = 1, to = 0.2, by = -0.2)
decrease <- rep(x = decrease, each = 10*16) # repeat each value years * steps times

# create a light vector with length years * steps + 1
parmax <- c(0, rep(2060, 50*16)*decrease)

# run the ACGCA model
acgcaout <- ACGCA::runacgca(sparms = acru, r0 = 0.0054, parmax = parmax, years = 50, steps = 16, fulloutput = FALSE)

# make a plot of the radius over time and the growth state over time.
par(mar=c(4,4,1,1))
plot(x= 1:801/16, y=acgcaout$r, xlab="years", ylab="radius (m)", type="l")
plot(x= 1:801/16, y=acgcaout$growth_st, xlab="years", ylab="growth state", type="l")

